import tkinter as tk
import re

# Password checking function
def check_password_strength():
    password = entry.get()

    strength = "Weak 😥"
    color = "red"

    if (len(password) >= 8 and
        re.search(r"[A-Z]", password) and
        re.search(r"[a-z]", password) and
        re.search(r"[0-9]", password) and
        re.search(r"[!@#$%^&*(),.?\":{}|<>/\\[\];'=_+-]", password)):
        strength = "Strong 💪"
        color = "lightgreen"
    elif len(password) >= 6:
        strength = "Moderate 🤔"
        color = "yellow"

    result_label.config(text=f"Password strength: {strength}", bg=color)

# GUI setup
root = tk.Tk()
root.title("Password Strength Checker 🩵")
root.config(bg="#f2f2f7")

# Entry label
label = tk.Label(root, text="Enter your password:", font=("Arial", 12), bg="#f2f2f7")
label.pack(pady=10)

# Entry field
entry = tk.Entry(root, show="*", width=30, font=("Arial", 12))
entry.pack()

# 🔐 Criteria label
criteria_text = (
    "Your password must contain:\n"
    "• At least 8 characters\n"
    "• At least one uppercase & one lowercase letter\n"
    "• At least one number\n"
    "• At least one special character (!@#...)\n"
)
criteria_label = tk.Label(root, text=criteria_text, font=("Arial", 9), fg="gray", bg="#f2f2f7", justify="left")
criteria_label.pack(pady=5)

# Check button
check_button = tk.Button(root, text="Check Strength", command=check_password_strength, font=("Arial", 11), bg="lightblue")
check_button.pack(pady=10)

# Result label
result_label = tk.Label(root, text="", font=("Arial", 14, "bold"), bg="#f2f2f7")
result_label.pack(pady=10)

root.mainloop()
