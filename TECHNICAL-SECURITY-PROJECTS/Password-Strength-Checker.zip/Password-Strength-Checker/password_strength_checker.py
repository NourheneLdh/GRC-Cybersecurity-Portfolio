import re
from colorama import Fore, Style, init
from datetime import datetime

# Initialize colorama
init(autoreset=True)

def check_password_strength(password):
    length_error = len(password) < 8
    lowercase_error = not re.search(r"[a-z]", password)
    uppercase_error = not re.search(r"[A-Z]", password)
    digit_error = not re.search(r"\d", password)
    special_error = not re.search(r"[!@#$%^&*(),.?\":{}|<>/\\~`+=_-]", password)

    errors = [length_error, lowercase_error, uppercase_error, digit_error, special_error]
    strength_score = 5 - sum(errors)

    if strength_score <= 2:
        strength = f"{Fore.RED}Weak 😥"
    elif strength_score == 3 or strength_score == 4:
        strength = f"{Fore.YELLOW}Moderate 🤔"
    else:
        strength = f"{Fore.GREEN}Strong 💪"

    return strength

# Optional logging function
def log_result(password, result):
    with open("password_check_log.txt", "a") as f:
        f.write(f"Password Checked: {'*' * len(password)}\n")
        f.write(f"Strength: {result.strip()}\n")
        f.write(f"Timestamp: {datetime.now()}\n\n")

# Main program
password = input("Enter your password: ")
strength_result = check_password_strength(password)
print(f"Password strength: {strength_result}")

# Uncomment the next line to enable logging
# log_result(password, strength_result)
