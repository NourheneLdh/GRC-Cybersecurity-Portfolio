import tkinter as tk
from tkinter import scrolledtext, messagebox
import socket
import threading
from datetime import datetime

# 🛡️ Function to scan a single port
def scan_port(ip, port, output):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1)  # Optional: faster scanning
            result = s.connect_ex((ip, port))
            if result == 0:
                output.insert(tk.END, f"✅ Port {port} is OPEN\n")
    except Exception as e:
        output.insert(tk.END, f"⚠️ Error scanning port {port}: {str(e)}\n")

# 🚀 Threaded scan function
def threaded_scan(ip, start_port, end_port, output, scan_btn):
    start_time = datetime.now()
    output.insert(tk.END, f"\n🕐 Scanning {ip} from port {start_port} to {end_port}...\n\n")
    threads = []

    for port in range(start_port, end_port + 1):
        t = threading.Thread(target=scan_port, args=(ip, port, output))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    end_time = datetime.now()
    duration = end_time - start_time
    output.insert(tk.END, f"\n⏱️ Scan completed in {duration} 🕐\n")
    scan_btn.config(state=tk.NORMAL)

# 🌟 Function triggered on button click
def start_scan(ip_entry, start_entry, end_entry, output, scan_btn):
    ip = ip_entry.get()
    try:
        socket.inet_aton(ip)
    except socket.error:
        messagebox.showerror("Invalid IP", "Please enter a valid IP address!")
        return

    try:
        start_port = int(start_entry.get())
        end_port = int(end_entry.get())
        if start_port < 0 or end_port > 65535 or start_port > end_port:
            raise ValueError
    except ValueError:
        messagebox.showerror("Invalid Ports", "Please enter valid port numbers (0-65535)!")
        return

    output.delete(1.0, tk.END)
    scan_btn.config(state=tk.DISABLED)
    threading.Thread(target=threaded_scan, args=(ip, start_port, end_port, output, scan_btn)).start()

# 💅 GUI Setup
root = tk.Tk()
root.title("✨ Port Scanner by Nounou 💖")
root.geometry("600x400")
root.resizable(False, False)

frame = tk.Frame(root)
frame.pack(pady=10)

tk.Label(frame, text="IP Address:").grid(row=0, column=0, padx=5)
ip_entry = tk.Entry(frame, width=20)
#ip_entry.insert(0, "127.0.0.1")
ip_entry.grid(row=0, column=1)

tk.Label(frame, text="Start Port:").grid(row=0, column=2, padx=5)
start_entry = tk.Entry(frame, width=10)
#start_entry.insert(0, "1")
start_entry.grid(row=0, column=3)

tk.Label(frame, text="End Port:").grid(row=0, column=4, padx=5)
end_entry = tk.Entry(frame, width=10)
#end_entry.insert(0, "1024")
end_entry.grid(row=0, column=5)

output = scrolledtext.ScrolledText(root, width=72, height=15, font=("Consolas", 10))
output.pack(pady=10)

scan_btn = tk.Button(root, text="💫 Start Scan 💫", bg="#FFC0CB", fg="black", command=lambda: start_scan(ip_entry, start_entry, end_entry, output, scan_btn))
scan_btn.pack(pady=5)

root.mainloop()
