import socket
from datetime import datetime

# Banner ✨
print("🔍 Simple Port Scanner - By Nounou 💻💖")
target = input("Enter the IP address to scan: ")
start_port = int(input("Start Port: "))
end_port = int(input("End Port: "))

print(f"\n🕐 Scanning {target} from port {start_port} to {end_port}...\n")
start_time = datetime.now()

# Scan logic
for port in range(start_port, end_port + 1):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    socket.setdefaulttimeout(1)
    result = sock.connect_ex((target, port))
    if result == 0:
        print(f"✅ Port {port} is OPEN")
    sock.close()

end_time = datetime.now()
total_time = end_time - start_time
print(f"\n⏱️ Scan completed in {total_time} 🕐")

